class AppAssets {
  // static String logoApp = 'assets/icons/blog.png';
  // static String logoApp = 'assets/svg/palestine_bird.svg';
  static String logoApp = 'assets/icons/palestine_bird.png';
  static String profile = 'assets/images/persone.jpg';
  static String menuAnimated = 'assets/images/persone.jpg';
  static String animated = 'assets/animation/animated.riv';
  static String noMails = 'assets/svg/no_mails_found.json';
}
